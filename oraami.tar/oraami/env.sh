export HNAME=oraami
export OHOME=/home/oracle
export ORACLE_HOME=/u01/app/oracle/product/12.2.0.1
export RUNDIR=/share/awsconfig/centos/$HNAME
