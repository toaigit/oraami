export HNAME=oraami
export OHOME=/home/oracle
export ORACLE_HOME=/u01/app/oracle/product/12.2.0.1
export ORAINV=/etc/oracle/oraInventory
export RUNDIR=/share/awsconfig/centos/$HNAME
#  ORASRC is oracle software download from oracle
#  ORARSP is the silent response file for install oracle in non-ui mode
export ORASRC=/share/software/ora12201/database
export ORARSP=/share/awsconfig/centos/oraami/db_codetree.rsp
export RUNLOG=/tmp/runcmd.log
